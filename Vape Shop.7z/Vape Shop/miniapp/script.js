// Экран загрузки
window.addEventListener('DOMContentLoaded', () => {
    const splashScreen = document.getElementById('splashScreen');
    const welcomeModal = document.getElementById('welcomeModal');
    
    // Скрываем splash screen через 2.5 секунды
    setTimeout(() => {
        splashScreen.classList.add('hidden');
        // Удаляем элемент из DOM после анимации
        setTimeout(() => {
            splashScreen.remove();
            // Показываем приветственное окно после splash screen
            welcomeModal.classList.add('active');
        }, 500);
    }, 2500);
});

// Инициализация Telegram WebApp
const tg = window.Telegram.WebApp;

console.log('=== ИНИЦИАЛИЗАЦИЯ TELEGRAM WEBAPP ===');
console.log('Telegram WebApp:', tg);
console.log('User:', tg.initDataUnsafe?.user);
console.log('Version:', tg.version);

// Проверка доступности sendData
if (typeof tg.sendData === 'function') {
    console.log('✅ tg.sendData() доступен');
} else {
    console.error('❌ tg.sendData() НЕ доступен!');
}

tg.expand();
// tg.enableClosingConfirmation(); // Убрано - может блокировать ввод

// Инициализация MainButton
console.log('🔘 Инициализация MainButton...');
tg.MainButton.hide(); // Скрываем до оформления заказа
console.log('✅ MainButton готова');

// База данных товаров (на основе kaifsmoke.com)
const products = [
    // ELFLIQ
    
    // ElfBar
    {
        id: 1,
        name: "ELFBAR ICE KING 30000 5% - Blackberry Cranberry",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с насыщенным и освежающим вкусом, который сочетает в себе терпкую чернику и кислую клюкву.",
        image: "./images/product-1.jpeg"
    },
    {
        id: 2,
        name: "ELFBAR ICE KING 30000 5% - Blue Razz Ice",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп для тех, кто любит ягодные вкусы с ярким и освежающим эффектом.",
        image: "./images/product-2.jpeg"
    },
    {
        id: 3,
        name: "ELFBAR ICE KING 30000 5% - Cherry Pomegranate Cranberry",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с изысканным сочетанием фруктов, которое дарит насыщенные и яркие вкусовые ощущения.",
        image: "./images/product-3.jpeg"
    },
    {
        id: 4,
        name: "ELFBAR ICE KING 30000 5% - ELF BULL",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с уникальным и мощным вкусом, припоминающим вкус известного энергетика, который сочетает в себе насыщенные фруктовые ноты с легким холодком.",
        image: "./images/product-4.jpeg"
    },
    {
        id: 5,
        name: "ELFBAR ICE KING 30000 5% - Grape Ice",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с насыщенным вкусом спелого винограда, который идеально сбалансирован с легким ментоловым холодком.",
        image: "./images/product-5.jpeg"
    },
    {
        id: 6,
        name: "ELFBAR ICE KING 30000 5% - Kiwi Passion Fruit Guava",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с ярким и экзотическим тройным фруктовым сочетанием: киви, маракуйя и гуавы.",
        image: "./images/product-6.jpeg"
    },
    {
        id: 7,
        name: "ELFBAR ICE KING 30000 5% - Lime Cola",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с уникальным и освежающим вкусом, который сочетает классическую колу с цитрусовой кислинкой лайма и лёгким холодком.",
        image: "./images/product-7.jpeg"
    },
    {
        id: 8,
        name: "ELFBAR ICE KING 30000 5% - Miami Mint",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с ярким, освежающим вкусом мяты, который дополнен лёгким тропическим акцентом.",
        image: "./images/product-8.jpeg"
    },
    {
        id: 9,
        name: "ELFBAR ICE KING 30000 5% - Peach Ice",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп, который сочетает в себе сладкий вкус спелого персика и прохладный ментоловый эффект.",
        image: "./images/product-9.jpeg"
    },
    {
        id: 10,
        name: "ELFBAR ICE KING 30000 5% - Pink Lemonade",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп с ярким и освежающим вкусом розового лимонада, который дарит идеальное сочетание сладости и легкой кислинки с добавлением прохлады.",
        image: "./images/product-10.jpeg"
    },
    {
        id: 11,
        name: "ELFBAR ICE KING 30000 5% - Ribena Lychee",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп, который сочетает в себе экзотический вкус личи и знакомую всем свежесть черной смородины.",
        image: "./images/product-11.jpeg"
    },
    {
        id: 12,
        name: "ELFBAR ICE KING 30000 5% - Strawberry Kiwi Ice",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп, который сочетает в себе яркую и взрывную смесь сладкой клубники и кислого киви с освежающим ледяным послевкусием.",
        image: "./images/product-12.jpeg"
    },
    {
        id: 13,
        name: "ELFBAR ICE KING 30000 5% - Strawberry Mango",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп, который сочетает в себе тропическую смесь спелой клубники и сочного манго для сладкого наслаждения.",
        image: "./images/product-13.jpeg"
    },
    {
        id: 14,
        name: "ELFBAR ICE KING 30000 5% - Watermelon Ice",
        category: "elfbar30k",
        price: 130,
        description: "Одноразовый вейп, который сочетает в себе сочный арбуз с освежающим ментоловым холодком для летнего настроения.",
        image: "./images/product-14.jpeg"
    },
    {
        id: 15,
        name: "ELFBAR GH 33000 PRO 5% - Granny Cherry",
        category: "elfbar33k",
        price: 140,
        description: "Глубокий и естественный вкус спелой вишни с лёгкой кислинкой и мягкой сладостью.",
        image: "./images/product-15.jpeg"
    },
    {
        id: 16,
        name: "ELFBAR GH 33000 PRO 5% - Grape Ice",
        category: "elfbar33k",
        price: 140,
        description: "Освежающий вкус спелого винограда с прохладной ледяной ноткой, которая добавляет бодрящий холодок.",
        image: "./images/product-16.jpeg"
    },
    {
        id: 17,
        name: "ELFBAR GH 33000 PRO 5% - Grapefruit Passion Guava",
        category: "elfbar33k",
        price: 140,
        description: "Яркий и сочный микс грейпфрута, маракуйи и гуавы с освежающей цитрусовой кислинкой и лёгкой тропической сладостью.",
        image: "./images/product-17.jpeg"
    },
    {
        id: 18,
        name: "ELFBAR GH 33000 PRO 5% - Blue Razz Ice",
        category: "elfbar33k",
        price: 140,
        description: "Яркий и насыщенный вкус спелой голубики с лёгкой кислинкой и прохладным ментоловым оттенком.",
        image: "./images/product-18.jpeg"
    },
    {
        id: 19,
        name: "ELFBAR GH 33000 PRO 5% - Mountain Mint",
        category: "elfbar33k",
        price: 140,
        description: "Свежий и прохладный вкус горной мяты с лёгкой сладостью и яркой ментоловой свежестью.",
        image: "./images/product-19.jpeg"
    },
    {
        id: 20,
        name: "ELFBAR GH 33000 PRO 5% - Pear Soda",
        category: "elfbar33k",
        price: 140,
        description: "Лёгкий и освежающий вкус спелой груши с пузырьками газированной воды.",
        image: "./images/product-20.jpeg"
    },
    {
        id: 21,
        name: "ELFBAR GH 33000 PRO 5% - Kiwi Pineapple Peach",
        category: "elfbar33k",
        price: 140,
        description: "Яркое и сочное сочетание кислого киви, сладкого ананаса и нежного персика.",
        image: "./images/product-21.jpeg"
    },
    {
        id: 22,
        name: "ELFBAR GH 33000 PRO 5% - Raspberry Grapefruit Lemon",
        category: "elfbar33k",
        price: 140,
        description: "Свежий и сочный вкус с гармоничным сочетанием спелой малины, горьковатого грейпфрута и освежающей лимонной кислинки.",
        image: "./images/product-22.jpeg"
    },
    {
        id: 23,
        name: "ELFBAR GH 33000 PRO 5% - Pomegranate Burst",
        category: "elfbar33k",
        price: 140,
        description: "Насыщенный вкус спелого граната с яркой кислинкой и лёгкой сладостью.",
        image: "./images/product-23.jpeg"
    },
    {
        id: 24,
        name: "ELFBAR GH 33000 PRO 5% - Sour Strawberry Dragonfruit",
        category: "elfbar33k",
        price: 140,
        description: "Яркое сочетание кислой клубники и экзотического драгонфрута с лёгкой сладостью и свежестью.",
        image: "./images/product-24.jpeg"
    },
    {
        id: 25,
        name: "ELFBAR GH 33000 PRO 5% - Cherry Pomegranate Pineapple",
        category: "elfbar33k",
        price: 140,
        description: "Сочное сочетание спелой вишни, яркого граната и сладкого ананаса.",
        image: "./images/product-25.jpeg"
    },
    {
        id: 26,
        name: "ELFBAR GH 33000 PRO 5% - Lemon Lime",
        category: "elfbar33k",
        price: 140,
        description: "Освежающее сочетание ярких лимонных и лаймовых нот с лёгкой кислинкой и мягкой сладостью.",
        image: "./images/product-26.jpeg"
    },
    {
        id: 27,
        name: "ELFBAR GH 33000 PRO 5% - Pine Needles",
        category: "elfbar33k",
        price: 140,
        description: "Насыщенный и свежий аромат хвои с лёгкими древесными и смолистыми нотами.",
        image: "./images/product-27.jpeg"
    },
    {
        id: 28,
        name: "ELFBAR GH 33000 PRO 5% - Apple Kiwi Ice",
        category: "elfbar33k",
        price: 140,
        description: "Свежий и сочный микс яблока и киви с лёгкой холодящей ноткой.",
        image: "./images/product-28.jpeg"
    },
    {
        id: 29,
        name: "ELFBAR SWEET KING 30000 5% - Apple Watermelon",
        category: "elfbar33ks",
        price: 140,
        description: "Погрузитесь в освежающую сладость спелого яблока и свежего арбуза — сочетание, которое подарит вам незабываемые моменты наслаждения.",
        image: "./images/product-29.jpeg"
    },
    {
        id: 30,
        name: "ELFBAR SWEET KING 30000 5% - Jasmine Raspberry",
        category: "elfbar33ks",
        price: 140,
        description: "Вдохновением для этого продукта послужили ароматы цветущего жасмина и спелой малины, которые гармонично переплетаются между собой, создавая насыщенный вкусовой букет.",
        image: "./images/product-30.jpeg"
    },
    {
        id: 31,
        name: "ELFBAR SWEET KING 30000 5% - Kiwi Pineapple Peach",
        category: "elfbar33ks",
        price: 140,
        description: "Невероятное сочетание киви, ананаса и персика.",
        image: "./images/product-31.jpeg"
    },
    {
        id: 32,
        name: "ELFBAR SWEET KING 30000 5% - Pine Needle Mint",
        category: "elfbar33ks",
        price: 140,
        description: "Новый вкус, который перенесет вас в свежесть соснового леса.",
        image: "./images/product-32.jpeg"
    },
    {
        id: 33,
        name: "ELFBAR SWEET KING 30000 5% - Strawberry Banana",
        category: "elfbar33ks",
        price: 140,
        description: "Вкус сочной клубники и спелого банана.",
        image: "./images/product-33.jpeg"
    },
    {
        id: 34,
        name: "ELFBAR SOUR KING 30000 5% - Red Raspberry Strawberry",
        category: "elfbar30sk",
        price: 130,
        description: "Это насыщенное сочетание сочной красной малины и сладкой клубники.",
        image: "./images/product-34.jpeg"
    },
    {
        id: 35,
        name: "ELFBAR SOUR KING 30000 5% - Sour Apple Candy",
        category: "elfbar30sk",
        price: 130,
        description: "Электронная сигарета со вкусом зелёного яблока и карамели.",
        image: "./images/product-35.jpeg"
    },
    {
        id: 36,
        name: "ELFBAR SOUR KING 30000 5% - Sour Apple Pear",
        category: "elfbar30sk",
        price: 130,
        description: "Представляет собой сочетание свежести зелёного яблока и тонкого аромата спелой груши.",
        image: "./images/product-36.jpeg"
    },
    {
        id: 37,
        name: "ELFBAR SOUR KING 30000 5% - Sour Blueberry Watermelon",
        category: "elfbar30sk",
        price: 130,
        description: "Подарит вам незабываемые ощущения благодаря сочетанию освежающей черники и сладкой медовой дыни.",
        image: "./images/product-37.jpeg"
    },
    {
        id: 38,
        name: "ELFBAR SOUR KING 30000 5% - Sour Kiwi Lemonade",
        category: "elfbar30sk",
        price: 130,
        description: "этот элегантный девайс обеспечит вам незабываемые впечатления благодаря насыщенному вкусу спелого зеленого киви и свежего лимона.",
        image: "./images/product-38.jpeg"
    },
    {
        id: 39,
        name: "ELFBAR SOUR KING 30000 5% - Sour Strawberry Kiwi",
        category: "elfbar30sk",
        price: 130,
        description: "Это взрыв свежести киви и сладости клубники.",
        image: "./images/product-39.jpeg"
    },
    {
        id: 40,
        name: "ELFBAR SOUR KING 30000 5% - Sour Triple Berry",
        category: "elfbar30k",
        price: 130,
        description: "Этот стильный девайс предлагает вам яркий букет из спелых лесных ягод, который подарит незабываемые ощущения при каждом вдохе.",
        image: "./images/product-40.jpeg"
    },
    {
        id: 41,
        name: "ELFBAR MOONNIGHT 40000 5% - Cherry watermelon",
        category: "elfbar40k",
        price: 140,
        description: "Сладкая вишня с сочным арбузом и легким прохладным шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-41.jpeg"
    },
    {
        id: 42,
        name: "ELFBAR MOONNIGHT 40000 5% - Grape Raspberry",
        category: "elfbar40k",
        price: 140,
        description: "Это сочетание спелого винограда и терпкой малины с легким прохладным шлейфом.",
        image: "./images/product-42.jpeg"
    },
    {
        id: 43,
        name: "ELFBAR MOONNIGHT 40000 5% - Lime Cola",
        category: "elfbar40k",
        price: 140,
        description: "Бодрящий вкус колы с пикантной лаймовой кислинкой и тонким прохладным шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-43.jpeg"
    },
    {
        id: 44,
        name: "ELFBAR MOONNIGHT 40000 5% - Blue razz ice",
        category: "elfbar40k",
        price: 140,
        description: "Яркая голубая малина с сочной сладостью и легким прохладным шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-44.jpeg"
    },
    {
        id: 45,
        name: "ELFBAR MOONNIGHT 40000 5% - Grape ice",
        category: "elfbar40k",
        price: 140,
        description: "Сочный вкус спелого винограда с легкой сладостью и освежающим ментоловым послевкусием, идеально сбалансированный для яркого вейпинга.",
        image: "./images/product-45.jpeg"
    },
    {
        id: 46,
        name: "ELFBAR MOONNIGHT 40000 5% - Lemon Lime",
        category: "elfbar40k",
        price: 140,
        description: "Искры лимона и лайма с яркой цитрусовой кислинкой и легким прохладным шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-46.jpeg"
    },
    {
        id: 47,
        name: "ELFBAR MOONNIGHT 40000 5% - Mango peach watermelon",
        category: "elfbar40k",
        price: 140,
        description: "Это яркий микс сладкого манго, сочного персика и освежающего арбуза с мягкой фруктовой гармонией.",
        image: "./images/product-47.jpeg"
    },
    {
        id: 48,
        name: "ELFBAR MOONNIGHT 40000 5% - Miami mint",
        category: "elfbar40k",
        price: 140,
        description: "Свежая мята с бодрящей прохладой и легким сладковатым шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-48.jpeg"
    },
    {
        id: 49,
        name: "ELFBAR MOONNIGHT 40000 5% - Pomegranate Burst",
        category: "elfbar40k",
        price: 140,
        description: "Терпкий гранат с яркой сладостью и легким прохладным шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-49.jpeg"
    },
    {
        id: 50,
        name: "ELFBAR MOONNIGHT 40000 5% - Kiwi Passion Fruit Guava",
        category: "elfbar40k",
        price: 140,
        description: "Сочетание свежести киви, насыщенного вкуса маракуйи и тропической сладости гуавы, создает приятный и слегка освежающий, но не охлаждающий вкус.",
        image: "./images/product-50.jpeg"
    },
    {
        id: 51,
        name: "ELFBAR MOONNIGHT 40000 5% - Watermelon Ice",
        category: "elfbar40k",
        price: 140,
        description: "Сочный арбуз с освежающей ментоловой прохладой и легким сладким шлейфом, идеально сбалансированный для яркого опыта.",
        image: "./images/product-51.jpeg"
    },
    {
        id: 52,
        name: "ELFBAR RAYA D3 25000 5% - Strawberry Raspberry cherry",
        category: "elfbar25k",
        price: 120,
        description: "Яркое сочетание сладости и кислинки: нежная клубника, сочная малина и насыщенная вишня создают взрывной ягодный вкус с освежающими нотками.",
        image: "./images/product-52.jpeg"
    },
    {
        id: 53,
        name: "ELFBAR RAYA D3 25000 5% - Blackberry pomegranate cherry",
        category: "elfbar25k",
        price: 120,
        description: "Это насыщенный вкус, в котором сочные ягоды ежевики переплетаются с терпкостью граната и сладостью спелой вишни, создавая яркий, глубокий и освежающий букет.",
        image: "./images/product-53.jpeg"
    },
    {
        id: 54,
        name: "ELFBAR RAYA D3 25000 5% - Strawberry Watermelon",
        category: "elfbar25k",
        price: 120,
        description: "Сладкий и освежающий вкус, где сочная клубника встречается с нежной, медовой акватикой арбуза, создавая летнюю гармонию.",
        image: "./images/product-54.jpeg"
    },
    {
        id: 55,
        name: "ELFBAR RAYA D3 25000 5% - Blackberry Cranberry",
        category: "elfbar25k",
        price: 120,
        description: "Вкус спелой ежевики и сочной клюквы.",
        image: "./images/product-55.jpeg"
    },
    {
        id: 56,
        name: "ELFBAR RAYA D3 25000 5% - Apple Peach",
        category: "elfbar25k",
        price: 120,
        description: "Это идеальное сочетание двух самых сочных фруктов, яблока и персика.",
        image: "./images/product-56.jpeg"
    },
    {
        id: 57,
        name: "ELFBAR RAYA D3 25000 5% - Strawberry Ice",
        category: "elfbar25k",
        price: 120,
        description: "Это освежающий микс сладкой спелой клубники и холодного ментола, создающий приятное ощущение ледяной свежести.",
        image: "./images/product-57.jpeg"
    },
    {
        id: 58,
        name: "ELFBAR RAYA D3 25000 5% - Grape Mint",
        category: "elfbar25k",
        price: 120,
        description: "Это гармоничное сочетание сочного винограда и освежающей мяты, которое дарит насыщенный и в то же время лёгкий вкус.",
        image: "./images/product-58.jpeg"
    },
    {
        id: 59,
        name: "ELFBAR RAYA D3 25000 5% - Apple shisha",
        category: "elfbar25k",
        price: 120,
        description: "Это освежающий вкус сочного яблока",
        image: "./images/product-59.jpeg"
    },
    {
        id: 60,
        name: "ELFBAR RAYA D3 25000 5% - Lemon Lime Ice",
        category: "elfbar25k",
        price: 120,
        description: "Ээто идеально сбалансированный микс яркого лимона и соковитого лайма дарит насыщенный, бодрящий вкус, который буквально пробуждает з первых затяжек.",
        image: "./images/product-60.jpeg"
    },
    {
        id: 61,
        name: "ELFBAR RAYA D3 25000 5% - Alpine Mint",
        category: "elfbar25k",
        price: 120,
        description: "Обладает приятным мятным ароматом. Этот вкус понравится любителям свежести и мятной жвачки.",
        image: "./images/product-61.jpeg"
    },
    {
        id: 62,
        name: "ELFBAR RAYA D3 25000 5% - Blueberry Ice",
        category: "elfbar25k",
        price: 120,
        description: "Вкус сочной спелой черники с ледяным холодком.",
        image: "./images/product-62.jpeg"
    },
    {
        id: 63,
        name: "ELFBAR RAYA D3 25000 5% - Blueberry Raspberry",
        category: "elfbar25k",
        price: 120,
        description: "Это насыщенное сочетание вкусов черники и малины.",
        image: "./images/product-63.jpeg"
    },
    {
        id: 64,
        name: "ELFBAR RAYA D3 25000 5% - Double Apple",
        category: "elfbar25k",
        price: 120,
        description: "Объединение двух яблок, которые придают вкусу сочность, сладость и легкую кислинку.",
        image: "./images/product-64.jpeg"
    },
    {
        id: 65,
        name: "ELFBAR RAYA D3 25000 5% - Grape Ice",
        category: "elfbar25k",
        price: 120,
        description: "Это освежающий вкус, в котором яркая сладость винограда сочетается с прохладным ментоловым акцентом.",
        image: "./images/product-65.jpeg"
    },
    {
        id: 66,
        name: "ELFBAR RAYA D3 25000 5% - Kiwi Passion Fruit Guava",
        category: "elfbar25k",
        price: 120,
        description: "В этом вкусе сочетаются свежесть и яркость киви, нежная сладость и аромат маракуйи, а также экзотическая и сочная гуава.",
        image: "./images/product-66.jpeg"
    },
    {
        id: 67,
        name: "ELFBAR RAYA D3 25000 5% - Kiwi Pineapple Ice",
        category: "elfbar25k",
        price: 120,
        description: "Насыщенный вкус спелого киви, сладкого ананаса и ледяной прохлады.",
        image: "./images/product-67.jpeg"
    },
    {
        id: 68,
        name: "ELFBAR RAYA D3 25000 5% - Peach Berry",
        category: "elfbar25k",
        price: 120,
        description: "Сочетает сладкий вкус спелого персика с искристыми нотками сочных ягод.",
        image: "./images/product-68.jpeg"
    },
    {
        id: 69,
        name: "ELFBAR RAYA D3 25000 5% - Peach Ice",
        category: "elfbar25k",
        price: 120,
        description: "Сочетает в себе сладкий и сочный вкус спелого персика с прохладным ледяным акцентом.",
        image: "./images/product-69.jpeg"
    },
    {
        id: 70,
        name: "ELFBAR RAYA D3 25000 5% - Strawberry Grape",
        category: "elfbar25k",
        price: 120,
        description: "Сочетает в себе сладкий вкус спелой клубники с освежающим вкусом винограда.",
        image: "./images/product-70.jpeg"
    },
    {
        id: 71,
        name: "ELFBAR RAYA D3 25000 5% - Vimto",
        category: "elfbar25k",
        price: 120,
        description: "Сочетает в себе ягодные и фруктовые нотки с легкими специями и прохладным оттенком.",
        image: "./images/product-71.jpeg"
    },
    {
        id: 72,
        name: "ELFBAR RAYA D3 25000 5% - Watermelon Bubble Gum",
        category: "elfbar25k",
        price: 120,
        description: "Сочетает освежающий вкус арбуза с нотками сладкой жвачки.",
        image: "./images/product-72.jpeg"
    },
    {
        id: 73,
        name: "ELFBAR RAYA D3 25000 5% - Watermelon Ice",
        category: "elfbar25k",
        price: 120,
        description: "Освежающий вкус, сочетающий насыщенный аромат спелого арбуза с прохладным ледяным оттенком.",
        image: "./images/product-73.jpeg"
    },
    {
        id: 74,
        name: "ELFBAR RAYA D3 25000 5% - Watermelon Lemon",
        category: "elfbar25k",
        price: 120,
        description: "Сочный и освежающий вкус, сочетающим сладкий аромат спелого кавуна с яркими цитрусовыми нотками лимона.",
        image: "./images/product-74.jpeg"
    },
    {
        id: 75,
        name: "Chapman Grape",
        category: "chapman",
        price: 40,
        description: "Ароматные сигареты с мягким вкусом спелого винограда. Легкий сладковатый оттенок дополняет классическую табачную основу, создавая приятный, ненавязчивый букет. Отличный выбор для тех, кто ценит фруктовую свежесть и мягкое послевкусие.",
        image: "./images/product-75.jpeg"
    },
    {
        id: 76,
        name: "Chapman Cherry",
        category: "chapman",
        price: 40,
        description: "Классика ароматизированных сигарет — насыщенный аромат спелой вишни, обрамлённый сбалансированным табачным вкусом. Лёгкая сладость и фруктовая кислинка делают Chapman Cherry узнаваемыми с первой затяжки. Идеальны для ценителей ярких вкусов.",
        image: "./images/product-76.jpeg"
    },
    {
        id: 77,
        name: "Chapman Chocolate",
        category: "chapman",
        price: 40,
        description: "Глубокий, тёплый вкус шоколада с деликатными нотами какао и мягкого табака. Chapman Chocolate создают ощущение уюта и лёгкой сладости, не теряя фирменной табачной насыщенности. Приятный выбор для вечернего отдыха.",
        image: "./images/product-77.jpeg"
    },
    {
        id: 78,
        name: "Chapman Apple",
        category: "chapman",
        price: 40,
        description: "Свежие, лёгкие и ароматные — Chapman Apple сочетают естественную сладость зелёного яблока с классическим табачным телом. Вкус освежает, а аромат дарит лёгкость и баланс. Подойдут для любителей фруктовых акцентов без лишней сладости.",
        image: "./images/product-78.jpeg"
    },
    {
        id: 79,
        name: "Sobranie Russian Black",
        category: "sobranie",
        price: 40,
        description: "Элегантная классика в черном исполнении. Богатый, насыщенный табачный вкус с лёгкими нотами пряностей и древесного дыма. Каждая сигарета — воплощение стиля, глубины и британской утончённости.",
        image: "./images/product-79.jpeg"
    },
    {
        id: 80,
        name: "Sobranie Cocktail",
        category: "sobranie",
        price: 40,
        description: "Яркие, утончённые и узнаваемые — Sobranie Cocktail сочетают мягкий табак премиум-класса с лёгким ароматом сладости. Цветные фильтры и сбалансированный вкус создают атмосферу праздника и роскоши в каждой затяжке.",
        image: "./images/product-80.jpeg"
    },
    {
        id: 81,
        name: "ELFBAR BC18000 - Blackberry Cherry",
        category: "elfbar18k",
        price: 100,
        description: "Сочное сочетание спелой ежевики и сладкой вишни — глубокий ягодный вкус с лёгкой кислинкой и мягким послевкусием.",
        image: "./images/product-81.jpeg"
    },
    {
        id: 82,
        name: "ELFBAR BC18000 - Blue Razz Ice",
        category: "elfbar18k",
        price: 100,
        description: "Классика среди вейперов — яркий микс голубики и малины с освежающим ледяным акцентом. Холодок и сладость в идеальном балансе.",
        image: "./images/product-82.jpeg"
    },
    {
        id: 83,
        name: "ELFBAR BC18000 - Cherry Lime",
        category: "elfbar18k",
        price: 100,
        description: "Вишнёвая сладость и лаймовая кислинка — бодрящий, цитрусово-ягодный вкус с искрящей свежестью.",
        image: "./images/product-83.jpeg"
    },
    {
        id: 84,
        name: "ELFBAR BC18000 - Grape Cranberry",
        category: "elfbar18k",
        price: 100,
        description: "Насыщенный виноград, дополненный кисло-сладкой клюквой. Вкус, который приятно раскрывается с каждым вдохом.",
        image: "./images/product-84.jpeg"
    },
    {
        id: 85,
        name: "ELFBAR BC18000 - Grape Ice",
        category: "elfbar18k",
        price: 100,
        description: "Холодный виноград с освежающим ментоловым финишем. Классика с чистым, кристально-свежим вкусом.",
        image: "./images/product-85.jpeg"
    },
    {
        id: 86,
        name: "ELFBAR BC18000 - Peach Mango Watermelon",
        category: "elfbar18k",
        price: 100,
        description: "Тропическая комбинация персика, манго и арбуза — сладкий, сочный и по-летнему лёгкий вкус.",
        image: "./images/product-86.jpeg"
    },
    {
        id: 87,
        name: "ELFBAR BC18000 - Pepper Mint",
        category: "elfbar18k",
        price: 100,
        description: "Интенсивная свежесть мяты с лёгкой пряной нотой. Чистый, освежающий вкус для любителей ментола.",
        image: "./images/product-87.jpeg"
    },
    {
        id: 88,
        name: "ELFBAR BC18000 - Pineapple Dragonfruit",
        category: "elfbar18k",
        price: 100,
        description: "Экзотический дуэт ананаса и питахайи — яркий, ароматный и немного кисленький вкус с тропическим характером.",
        image: "./images/product-88.jpeg"
    },
    {
        id: 89,
        name: "ELFBAR BC18000 - Sour Apple",
        category: "elfbar18k",
        price: 100,
        description: "Ярко-кислый зелёный яблоко — взрыв свежести и сочности, идеально сбалансированный вкус.",
        image: "./images/product-89.jpeg"
    }
];

// Состояние приложения
let cart = JSON.parse(localStorage.getItem('cart')) || [];
let currentCategory = 'all';
let searchQuery = '';
let sortOrder = 'default';

// Элементы DOM
const productsGrid = document.getElementById('productsGrid');
const cartBtn = document.getElementById('cartBtn');
const cartCount = document.getElementById('cartCount');
const cartModal = document.getElementById('cartModal');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const totalPrice = document.getElementById('totalPrice');
const clearCart = document.getElementById('clearCart');
const checkoutBtn = document.getElementById('checkoutBtn');
const searchInput = document.getElementById('searchInput');
const categoryTabs = document.querySelectorAll('.category-tab');
const sortSelect = document.getElementById('sortSelect');
const checkoutModal = document.getElementById('checkoutModal');
const closeCheckout = document.getElementById('closeCheckout');
const backToCart = document.getElementById('backToCart');
const submitOrder = document.getElementById('submitOrder');
const deliveryMethod = document.getElementById('deliveryMethod');
const addressGroup = document.getElementById('addressGroup');

// Инициализация
function init() {
    renderProducts();
    updateCartUI();
    setupEventListeners();
}

// Настройка обработчиков событий
function setupEventListeners() {
    // Приветственное окно
    const closeWelcome = document.getElementById('closeWelcome');
    const goToCatalog = document.getElementById('goToCatalog');
    const welcomeModal = document.getElementById('welcomeModal');
    
    if (closeWelcome) {
        closeWelcome.addEventListener('click', () => {
            welcomeModal.classList.remove('active');
        });
    }
    
    if (goToCatalog) {
        goToCatalog.addEventListener('click', () => {
            welcomeModal.classList.remove('active');
            // Плавно прокручиваем к каталогу
            const catalogSection = document.getElementById('productsGrid');
            if (catalogSection) {
                catalogSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    }
    
    // Закрытие приветственного окна по клику вне его
    welcomeModal.addEventListener('click', (e) => {
        if (e.target === welcomeModal) {
            welcomeModal.classList.remove('active');
        }
    });
    
    // Поиск
    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        renderProducts();
    });

    // Категории
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            categoryTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            currentCategory = tab.dataset.category;
            renderProducts();
        });
    });

    // Сортировка
    sortSelect.addEventListener('change', (e) => {
        sortOrder = e.target.value;
        renderProducts();
    });

    // Корзина
    cartBtn.addEventListener('click', openCart);
    closeCart.addEventListener('click', () => cartModal.classList.remove('active'));
    clearCart.addEventListener('click', () => {
        if (confirm('Очистить корзину?')) {
            cart = [];
            saveCart();
            updateCartUI();
            renderCart();
        }
    });
    checkoutBtn.addEventListener('click', openCheckout);

    // Оформление заказа
    closeCheckout.addEventListener('click', () => checkoutModal.classList.remove('active'));
    backToCart.addEventListener('click', () => {
        checkoutModal.classList.remove('active');
        cartModal.classList.add('active');
    });
    submitOrder.addEventListener('click', handleSubmitOrder);

    // Показ/скрытие поля адреса
    deliveryMethod.addEventListener('change', (e) => {
        if (e.target.value === 'pickup') {
            addressGroup.style.display = 'none';
            document.getElementById('deliveryAddress').required = false;
        } else {
            addressGroup.style.display = 'block';
            document.getElementById('deliveryAddress').required = true;
        }
    });

    // Закрытие модалок по клику вне их
    cartModal.addEventListener('click', (e) => {
        if (e.target === cartModal) {
            cartModal.classList.remove('active');
        }
    });
    checkoutModal.addEventListener('click', (e) => {
        if (e.target === checkoutModal) {
            checkoutModal.classList.remove('active');
        }
    });
}

// Отрисовка товаров
function renderProducts() {
    let filteredProducts = products.filter(product => {
        const matchCategory = currentCategory === 'all' || product.category === currentCategory;
        const matchSearch = product.name.toLowerCase().includes(searchQuery) || 
                          product.description.toLowerCase().includes(searchQuery);
        return matchCategory && matchSearch;
    });

    // Сортировка
    if (sortOrder === 'price-asc') {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (sortOrder === 'price-desc') {
        filteredProducts.sort((a, b) => b.price - a.price);
    }

    if (filteredProducts.length === 0) {
        productsGrid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #000000;">
                <div style="font-size: 60px; margin-bottom: 15px;">🔍</div>
                <h3 style="color: #000000;">Товары не найдены</h3>
                <p style="color: #757575;">Попробуйте изменить фильтры или поисковый запрос</p>
            </div>
        `;
        return;
    }

    productsGrid.innerHTML = filteredProducts.map(product => `
        <div class="product-card" data-id="${product.id}">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <h3 class="product-name">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-footer">
                <span class="product-price">${product.price} zł</span>
                <button class="add-to-cart-btn" onclick="addToCart(${product.id})">
                    В корзину
                </button>
            </div>
        </div>
    `).join('');
}

// Добавление в корзину
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCart();
    updateCartUI();

    // Анимация кнопки корзины
    cartBtn.style.transform = 'scale(1.2)';
    setTimeout(() => {
        cartBtn.style.transform = 'scale(1)';
    }, 200);

    // Вибрация (если поддерживается)
    if (tg.HapticFeedback) {
        tg.HapticFeedback.impactOccurred('light');
    }
}

// Обновление UI корзины
function updateCartUI() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
}

// Открытие корзины
function openCart() {
    renderCart();
    cartModal.classList.add('active');
}

// Отрисовка корзины
function renderCart() {
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <div class="empty-cart-icon">🛒</div>
                <h3 style="color: #FFFFFF;">Корзина пуста</h3>
                <p style="color: #CCCCCC;">Добавьте товары из каталога</p>
            </div>
        `;
        totalPrice.textContent = '0 zł';
        checkoutBtn.disabled = true;
        return;
    }

    checkoutBtn.disabled = false;

    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" class="cart-item-image">
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${item.price} zł</div>
                <div class="cart-item-controls">
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">−</button>
                    <span class="quantity">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    <button class="remove-btn" onclick="removeFromCart(${item.id})">Удалить</button>
                </div>
            </div>
        </div>
    `).join('');

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    totalPrice.textContent = `${total} zł`;
}

// Изменение количества
function updateQuantity(productId, change) {
    const item = cart.find(i => i.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(productId);
            return;
        }
        saveCart();
        updateCartUI();
        renderCart();
    }
}

// Удаление из корзины
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartUI();
    renderCart();
}

// Сохранение корзины
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Открытие формы оформления
function openCheckout() {
    if (cart.length === 0) return;

    cartModal.classList.remove('active');
    checkoutModal.classList.add('active');

    // Заполнение данных пользователя из Telegram
    console.log('📝 Заполнение данных пользователя');
    console.log('tg.initDataUnsafe:', tg.initDataUnsafe);
    
    if (tg.initDataUnsafe && tg.initDataUnsafe.user) {
        const user = tg.initDataUnsafe.user;
        console.log('User данные:', user);
        
        // Имя
        const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
        if (fullName) {
            document.getElementById('customerName').value = fullName;
            console.log('✅ Имя заполнено:', fullName);
        }
    } else {
        console.warn('⚠️ Данные пользователя недоступны');
    }

    // Отрисовка итогов заказа
    renderOrderSummary();
}

// Отрисовка итогов заказа
function renderOrderSummary() {
    const orderSummary = document.getElementById('orderSummary');
    const orderTotal = document.getElementById('orderTotal');

    orderSummary.innerHTML = cart.map(item => `
        <div class="order-item">
            <span>${item.name} x ${item.quantity}</span>
            <span>${item.price * item.quantity} zł</span>
        </div>
    `).join('');

    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    orderTotal.textContent = `${total} zł`;
}

// Генерация уникального ID заказа
function generateOrderId() {
    const timestamp = Date.now().toString(36);
    const randomStr = Math.random().toString(36).substring(2, 15);
    return (timestamp + randomStr).substring(0, 20);
}

// Конвертация валюты (1 zł ≈ 11.48 грн)
function convertToUAH(amountInZloty) {
    const rate = 11.48;
    return (amountInZloty * rate).toFixed(2);
}

// Отправка заказа
function handleSubmitOrder() {
    console.log('🔵 Кнопка "Отправить заказ" нажата');
    
    const form = document.getElementById('checkoutForm');
    
    if (!form.checkValidity()) {
        console.log('❌ Форма не валидна');
        form.reportValidity();
        return;
    }
    
    console.log('✅ Форма валидна');

    // Проверка Telegram WebApp
    if (!window.Telegram || !window.Telegram.WebApp) {
        alert('❌ Ошибка: Telegram WebApp не доступен. Откройте через бота!');
        console.error('Telegram WebApp недоступен');
        return;
    }
    
    console.log('✅ Telegram WebApp доступен:', tg);

    const orderId = generateOrderId();
    const totalZloty = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const totalUAH = convertToUAH(totalZloty);

    const orderData = {
        order_id: orderId,
        customer: {
            name: document.getElementById('customerName').value,
            phone: document.getElementById('customerPhone').value,
            telegram_id: tg.initDataUnsafe?.user?.id || null,
            username: tg.initDataUnsafe?.user?.username || null,
            first_name: tg.initDataUnsafe?.user?.first_name || null,
            last_name: tg.initDataUnsafe?.user?.last_name || null
        },
        delivery: {
            method: document.getElementById('deliveryMethod').value,
            address: document.getElementById('deliveryAddress').value
        },
        payment: {
            method: document.getElementById('paymentMethod').value
        },
        comment: document.getElementById('orderComment').value,
        items: cart.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
        })),
        total: totalZloty,
        total_uah: totalUAH,
        timestamp: new Date().toISOString()
    };

    console.log('📦 Данные заказа:', orderData);
    
    const dataString = JSON.stringify(orderData);
    console.log('📏 Размер данных:', dataString.length, 'байт (макс 4096)');

    if (dataString.length > 4096) {
        alert('❌ Данные заказа слишком большие. Уберите лишние товары или комментарий.');
        console.error('Данные превышают лимит 4096 байт:', dataString.length);
        return;
    }

    try {
        console.log('🚀 Отправка заказа...');
        
        // Отправляем данные боту
        tg.sendData(dataString);
        console.log('✅ Данные отправлены!');
        
        // Очистка корзины
        cart = [];
        saveCart();
        updateCartUI();
        console.log('🗑️ Корзина очищена');
        
        // Закрываем модалку
        checkoutModal.classList.remove('active');
        
        // Показываем красивое уведомление
        const successMessage = document.createElement('div');
        successMessage.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #000000;
            color: #FFFFFF;
            padding: 30px 40px;
            border-radius: 15px;
            font-size: 18px;
            text-align: center;
            z-index: 10000;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
        `;
        successMessage.innerHTML = '✅<br><b>Заказ отправлен!</b><br><br>Скоро с вами свяжется менеджер';
        document.body.appendChild(successMessage);
        
        // Закрываем приложение через 2 секунды
        setTimeout(() => {
            tg.close();
        }, 2000);
        
    } catch (error) {
        console.error('❌ Ошибка при отправке заказа:', error);
        console.error('Стек ошибки:', error.stack);
        alert('❌ Ошибка отправки: ' + error.message);
    }
}

// MainButton больше не используется - отправка происходит сразу при нажатии "Отправить заказ"

// Глобальные функции для onclick
window.addToCart = addToCart;
window.updateQuantity = updateQuantity;
window.removeFromCart = removeFromCart;

// Запуск приложения
init();

