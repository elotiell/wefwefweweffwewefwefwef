# NextGenVape MiniApp

Telegram MiniApp для магазина вейпов с коричнево-золотистым дизайном.

## Возможности

✅ **Каталог товаров** - ELFLIQ, Chaser, ElfBar, Под-системы, Картриджи  
✅ **Поиск** - поиск по названию и описанию  
✅ **Категории** - фильтрация по категориям  
✅ **Сортировка** - по цене (дешёвые/дорогие)  
✅ **Корзина** - добавление товаров, изменение количества  
✅ **Оформление заказа** - выбор доставки и оплаты  
✅ **Интеграция с Telegram** - отправка данных боту  

## Структура проекта

```
miniapp/
├── index.html      # Главная страница
├── style.css       # Стили (коричнево-золотистая тема)
├── script.js       # JavaScript логика
└── README.md       # Документация
```

## Деплой

### Вариант 1: GitHub Pages (бесплатно)

1. **Создайте репозиторий на GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/ваш-username/nextgenvape-miniapp.git
   git push -u origin main
   ```

2. **Включите GitHub Pages**
   - Зайдите в Settings → Pages
   - Source: Deploy from a branch
   - Branch: main, папка: /miniapp
   - Сохраните

3. **Получите URL**
   - Ваш MiniApp будет доступен по адресу: `https://ваш-username.github.io/nextgenvape-miniapp/`

### Вариант 2: Vercel (бесплатно, рекомендуется)

1. **Установите Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Деплой**
   ```bash
   cd miniapp
   vercel
   ```

3. **Следуйте инструкциям**
   - Авторизуйтесь через GitHub
   - Выберите настройки проекта
   - Получите URL вида: `https://your-project.vercel.app`

### Вариант 3: Netlify (бесплатно)

1. **Зарегистрируйтесь на [Netlify](https://netlify.com)**

2. **Деплой через Drag & Drop**
   - Перетащите папку `miniapp` на страницу деплоя
   - Получите URL

3. **Или через Netlify CLI**
   ```bash
   npm install -g netlify-cli
   cd miniapp
   netlify deploy --prod
   ```

## Подключение к Telegram боту

1. **Получите URL вашего MiniApp** (после деплоя)

2. **Обновите bot.py**
   ```python
   SHOP_URL = "https://your-miniapp-url.vercel.app"
   ```

3. **Перезапустите бота**
   ```bash
   python bot.py
   ```

4. **Настройка в BotFather** (опционально)
   - Откройте @BotFather
   - Отправьте `/mybots`
   - Выберите своего бота
   - `Bot Settings` → `Menu Button` → `Edit Menu Button URL`
   - Вставьте URL вашего MiniApp

## Обработка заказов

Когда пользователь оформляет заказ, данные отправляются боту через `tg.sendData()`. 

**Формат данных:**
```json
{
  "customer": {
    "name": "Имя клиента",
    "phone": "+48123456789",
    "telegram_id": 123456789,
    "username": "username"
  },
  "delivery": {
    "method": "inpost|dpd|pickup",
    "address": "Адрес доставки"
  },
  "payment": {
    "method": "card|crypto|cash"
  },
  "comment": "Комментарий к заказу",
  "items": [
    {
      "id": 1,
      "name": "ELFLIQ Orange Soda",
      "price": 49,
      "quantity": 2
    }
  ],
  "total": 98
}
```

### Добавьте обработчик в bot.py:

```python
@dp.message(lambda msg: msg.web_app_data)
async def handle_order(message: types.Message):
    import json
    order_data = json.loads(message.web_app_data.data)
    
    # Форматирование заказа
    order_text = f"""
📦 <b>Новый заказ!</b>

👤 <b>Клиент:</b>
├ Имя: {order_data['customer']['name']}
├ Телефон: {order_data['customer']['phone']}
└ Username: @{order_data['customer'].get('username', 'не указан')}

🛍 <b>Товары:</b>
"""
    
    for item in order_data['items']:
        order_text += f"├ {item['name']} x{item['quantity']} = {item['price'] * item['quantity']} zł\n"
    
    order_text += f"""
💰 <b>Итого:</b> {order_data['total']} zł

🚚 <b>Доставка:</b> {order_data['delivery']['method']}
📍 <b>Адрес:</b> {order_data['delivery'].get('address', 'Самовывоз')}

💳 <b>Оплата:</b> {order_data['payment']['method']}

💬 <b>Комментарий:</b> {order_data.get('comment', 'нет')}
    """
    
    # Отправка менеджеру
    MANAGER_ID = "YOUR_MANAGER_TELEGRAM_ID"  # ID менеджера
    await bot.send_message(MANAGER_ID, order_text, parse_mode="HTML")
    
    # Подтверждение клиенту
    await message.answer(
        "✅ <b>Заказ принят!</b>\n\n"
        "Менеджер свяжется с вами в ближайшее время для подтверждения.",
        parse_mode="HTML"
    )
```

## Настройка товаров

Отредактируйте массив `products` в `script.js`:

```javascript
const products = [
    {
        id: 1,
        name: "Название товара",
        category: "chaser|elfliq|elfbar|pods|cartridges",
        price: 49,
        description: "Описание товара",
        image: "URL изображения"
    },
    // ... другие товары
];
```

## Настройка изображений

### Вариант 1: Внешние URL
Используйте изображения с любого хостинга (Imgur, ImgBB, CloudImage и т.д.)

### Вариант 2: Локальные изображения
1. Создайте папку `images` в `miniapp/`
2. Добавьте изображения
3. Обновите пути в `products`:
   ```javascript
   image: "./images/product1.jpg"
   ```

### Вариант 3: Base64 (для маленьких изображений)
Конвертируйте изображения в base64 и вставьте прямо в код.

## Цветовая схема

Коричнево-золотистая тема:

```css
--primary-color: #8B6F47;      /* Коричневый основной */
--secondary-color: #D4AF37;    /* Золотой */
--bg-color: #2C2416;           /* Тёмный фон */
--card-bg: #3D3424;            /* Фон карточек */
--text-color: #F5E6D3;         /* Текст светлый */
--accent-gold: #FFD700;        /* Яркое золото */
```

## Поддержка

Если возникли вопросы:
- Telegram: [@nextgenvapeadmin](https://t.me/nextgenvapeadmin)
- GitHub Issues: создайте issue в репозитории

## Лицензия

MIT License

