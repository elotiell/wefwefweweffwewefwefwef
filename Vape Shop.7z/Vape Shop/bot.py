import asyncio
import logging
import os
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import CommandStart, CommandObject
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Конфигурация
BOT_TOKEN = os.getenv("BOT_TOKEN", "7963768656:AAFB-BGg0rol2EyE6nC_vqgAitS8YjlNYNU")
MANAGER_URL = "https://t.me/nextgenvapeadmin"
SHOP_URL = "https://brilliant-eclair-39ad50.netlify.app"  # MiniApp на Netlify

# Инициализация бота
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Простое хранилище рефералов (в продакшене использовать БД)
referrals = {}

# Middleware для отладки всех апдейтов
from aiogram import BaseMiddleware
from typing import Callable, Dict, Any, Awaitable

class DebugMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[types.Message, Dict[str, Any]], Awaitable[Any]],
        event: types.Message,
        data: Dict[str, Any]
    ) -> Any:
        logger.info(f"🔍 MIDDLEWARE: Получен апдейт")
        logger.info(f"   От: {event.from_user.id if event.from_user else 'Unknown'}")
        logger.info(f"   Текст: {event.text}")
        logger.info(f"   web_app_data: {event.web_app_data}")
        
        if event.web_app_data:
            logger.info("   🎉 ЕСТЬ WEB_APP_DATA!")
            logger.info(f"   Данные: {event.web_app_data.data[:100]}...")
        
        return await handler(event, data)

# Подключаем middleware
dp.message.middleware(DebugMiddleware())

# Главное меню
def main_menu():
    builder = ReplyKeyboardBuilder()
    # ВАЖНО: Используем KeyboardButton с web_app для поддержки sendData()
    builder.button(text="🛍️ Магазин", web_app=types.WebAppInfo(url=SHOP_URL))
    builder.button(text="🎁 Получить промокод")
    builder.button(text="💬 Связаться с оператором")
    builder.button(text="❔ Помощь")
    builder.adjust(1, 1, 2)
    return builder.as_markup(resize_keyboard=True)

# /start
@dp.message(CommandStart())
async def start(message: types.Message, command: CommandObject):
    user = message.from_user
    args = command.args  # ← тут хранятся аргументы, например ref_123

    if args and args.startswith("ref_"):
        ref_id = args.split("_")[1]
        if ref_id != str(user.id):
            if ref_id not in referrals:
                referrals[ref_id] = []
            if user.id not in referrals[ref_id]:
                referrals[ref_id].append(user.id)
                try:
                    await bot.send_message(
                        ref_id,
                        f"🎉 Твой друг @{user.username or user.first_name} активировал бота по твоей ссылке!\n"
                        f"Ты получил промокод на скидку: <code>FRIEND10</code>",
                        parse_mode="HTML"
                    )
                except:
                    pass

    await message.answer(
        "👋 Добро пожаловать в <b>NextGenVape Shop!</b>\n\n"
        "Ты попал туда, где всё сделано для своих — удобно, быстро и с заботой 🙌\n\n"
        "Выбери действие ниже 👇",
        parse_mode="HTML",
        reply_markup=main_menu()
    )

# Кнопка: Получить промокод
@dp.message(lambda msg: msg.text == "🎁 Получить промокод")
async def promo(message: types.Message):
    ref_link = f"https://t.me/{(await bot.get_me()).username}?start=ref_{message.from_user.id}"
    await message.answer(
        f"🎁 Ваша персональная ссылка:\n\n<code>{ref_link}</code>\n\n"
        "Приглашайте друзей — за каждого активировавшего вы получите промокод на скидку 💨",
        parse_mode="HTML"
    )

# Магазин - теперь открывается напрямую через KeyboardButton с web_app
# Этот обработчик больше не нужен, так как MiniApp открывается автоматически при нажатии кнопки

# Связаться с оператором
@dp.message(lambda msg: msg.text == "💬 Связаться с оператором")
async def contact(message: types.Message):
    markup = types.InlineKeyboardMarkup(inline_keyboard=[
        [types.InlineKeyboardButton(text="Написать менеджеру", url=MANAGER_URL)]
    ])
    await message.answer("💬 Связаться с оператором:", reply_markup=markup)

# Помощь
@dp.message(lambda msg: msg.text == "❔ Помощь")
async def help_info(message: types.Message):
    text = (
        "🧾 <b>Как сделать заказ:</b>\n\n"
        "1. Нажмите «Магазин»\n"
        "2. Выберите товар через поиск или категории\n"
        "3. Добавьте в корзину и подтвердите заказ\n"
        "4. Выберите способ доставки:\n"
        "   • InPost Paczkomat\n"
        "   • DPD / DHL по всему миру\n"
        "   • Самовывоз с города Lodz\n"
        "5. Оплатите:\n"
        "   • На карту (PL / UA)\n"
        "   • Криптой\n"
        "   • При встрече\n\n"
        "Если остались вопросы — пишите менеджеру:\n"
        f"{MANAGER_URL}"
    )
    await message.answer(text, parse_mode="HTML")

# Хранилище заказов (в продакшене использовать БД)
orders = {}

# Обработка заказов из MiniApp
@dp.message(F.web_app_data)
async def handle_web_app_order(message: types.Message):
    """Обработка заказа из MiniApp"""
    import json
    
    # Удаляем системное сообщение "Data from..."
    try:
        await message.delete()
    except:
        pass
    
    logger.info(f"Получены данные WebApp от пользователя {message.from_user.id}")
    logger.info(f"Данные WebApp: {message.web_app_data.data[:200]}...")
    
    try:
        order_data = json.loads(message.web_app_data.data)
        order_id = order_data.get('order_id', 'unknown')
        
        logger.info(f"Обработка заказа #{order_id}")
        
        # Сохранение заказа
        orders[order_id] = {
            'user_id': message.from_user.id,
            'data': order_data,
            'status': 'pending'
        }
        
        # Форматирование товаров для клиента
        items_text = ""
        for item in order_data.get('items', []):
            items_text += f"• {item['name']} x{item['quantity']} — {item['price'] * item['quantity']:.2f} zł\n"
        
        # Способы доставки
        delivery_methods = {
            'inpost': 'InPost Paczkomat',
            'dpd': 'DPD / DHL',
            'pickup': 'Самовывоз'
        }
        
        delivery_text = delivery_methods.get(order_data.get('delivery', {}).get('method', ''), 'Не указана')
        if order_data.get('delivery', {}).get('method') == 'pickup':
            address = order_data.get('delivery', {}).get('address', 'Lodz')
            delivery_text = f"Забрать сейчас в {address}"
        else:
            delivery_text = f"{delivery_text}: {order_data.get('delivery', {}).get('address', '')}"
        
        # Способ оплаты для клиента
        payment_methods_client = {
            'card': 'На карту (PL / UA)',
            'crypto': 'Криптовалюта',
            'cash': 'При встрече'
        }
        payment_text = payment_methods_client.get(order_data.get('payment', {}).get('method', ''), 'Не указан')
        
        # Сообщение клиенту
        client_message = f"""✅ <b>Ваш заказ отправлен!</b>

🎫 <b>Номер заказа:</b> <code>#{order_id}</code>

🛍 <b>Состав заказа:</b>
{items_text}
💰 <b>Сумма к оплате:</b> {order_data.get('total', 0):.2f} zł ({order_data.get('total_uah', 0)} грн)

🚚 <b>Способ доставки:</b>
{delivery_text}

💳 <b>Способ оплаты:</b>
{payment_text}"""
        
        if order_data.get('comment'):
            client_message += f"\n\n💬 <b>Ваш комментарий:</b>\n{order_data.get('comment')}"
        
        client_message += f"""

━━━━━━━━━━━━━━━━━━━
⏳ <b>Ожидайте подтверждения от поддержки!</b>

Наш менеджер свяжется с вами в ближайшее время для подтверждения заказа и уточнения деталей доставки.

📞 Среднее время ответа: <b>5-15 минут</b>"""
        
        # Кнопки для клиента
        keyboard = InlineKeyboardBuilder()
        keyboard.button(text="❌ Отменить заказ", callback_data=f"cancel_order:{order_id}")
        keyboard.button(text="💬 Связаться с менеджером", url=MANAGER_URL)
        keyboard.adjust(1)
        
        # Отправка клиенту
        await message.answer(
            client_message,
            parse_mode="HTML",
            reply_markup=keyboard.as_markup()
        )
        
        # Форматирование сообщения для менеджера
        payment_methods = {
            'card': 'На карту (PL / UA)',
            'crypto': 'Криптовалюта',
            'cash': 'При встрече'
        }
        
        customer = order_data.get('customer', {})
        
        # Если данные не пришли из MiniApp, берем из message.from_user
        telegram_id = customer.get('telegram_id') or message.from_user.id
        username = customer.get('username') or message.from_user.username or 'нет'
        first_name = customer.get('first_name') or message.from_user.first_name or ''
        last_name = customer.get('last_name') or message.from_user.last_name or ''
        
        manager_message = f"""📦 <b>НОВЫЙ ЗАКАЗ #{order_id}</b>

👤 <b>Клиент:</b>
├ Имя: {customer.get('name', 'Не указано')}
├ Телефон: {customer.get('phone', 'Не указан')}
├ Telegram: @{username}
└ ID: <code>{telegram_id}</code>

🛍 <b>Товары:</b>
{items_text}
💰 <b>Итого:</b> {order_data.get('total', 0):.2f} zł ({order_data.get('total_uah', 0)} грн)

🚚 <b>Доставка:</b> {delivery_text}

💳 <b>Оплата:</b> {payment_methods.get(order_data.get('payment', {}).get('method', ''), 'Не указана')}

💬 <b>Комментарий:</b> {order_data.get('comment', 'Нет')}

📅 <b>Дата:</b> {order_data.get('timestamp', 'N/A')}
"""
        
        # Кнопки для менеджера
        manager_keyboard = InlineKeyboardBuilder()
        manager_keyboard.button(text="✅ Одобрить", callback_data=f"confirm_order:{order_id}")
        manager_keyboard.button(text="❌ Отменить", callback_data=f"manager_cancel:{order_id}")
        manager_keyboard.button(text="💬 Связаться", url=f"tg://user?id={telegram_id}")
        manager_keyboard.adjust(2, 1)
        
        # Отправка менеджеру (укажите ID менеджера)
        MANAGER_ID = "51712955"  # Ваш Telegram ID
        if MANAGER_ID:
            try:
                await bot.send_message(
                    int(MANAGER_ID),
                    manager_message,
                    parse_mode="HTML",
                    reply_markup=manager_keyboard.as_markup()
                )
                logger.info(f"Заказ #{order_id} отправлен менеджеру. User: {message.from_user.id}")
            except Exception as e:
                logger.error(f"Ошибка отправки заказа менеджеру: {e}")
        
        logger.info(f"Получен заказ #{order_id} от пользователя {message.from_user.id}: {order_data.get('total', 0)} zł")
        
    except json.JSONDecodeError:
        await message.answer(
            "❌ Ошибка обработки заказа. Попробуйте снова или свяжитесь с менеджером.",
            parse_mode="HTML"
        )
        logger.error(f"Ошибка парсинга данных WebApp от пользователя {message.from_user.id}")
    except Exception as e:
        await message.answer(
            "❌ Произошла ошибка при оформлении заказа. Пожалуйста, свяжитесь с менеджером.",
            parse_mode="HTML"
        )
        logger.error(f"Ошибка обработки заказа: {e}")

# Обработка отмены заказа клиентом
@dp.callback_query(F.data.startswith("cancel_order:"))
async def handle_cancel_order(callback: types.CallbackQuery):
    """Отмена заказа клиентом"""
    order_id = callback.data.split(":")[1]
    
    if order_id in orders:
        orders[order_id]['status'] = 'cancelled_by_client'
        await callback.message.edit_text(
            f"❌ <b>Заказ #{order_id} отменен</b>\n\n"
            "Если у вас есть вопросы, свяжитесь с менеджером.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardBuilder().button(
                text="💬 Связаться с менеджером",
                url=MANAGER_URL
            ).as_markup()
        )
        logger.info(f"Заказ #{order_id} отменен клиентом {callback.from_user.id}")
    else:
        await callback.answer("Заказ не найден", show_alert=True)
    
    await callback.answer()

# Обработка подтверждения заказа менеджером
@dp.callback_query(F.data.startswith("confirm_order:"))
async def handle_confirm_order(callback: types.CallbackQuery):
    """Подтверждение заказа менеджером"""
    order_id = callback.data.split(":")[1]
    
    if order_id in orders:
        order = orders[order_id]
        order['status'] = 'confirmed'
        
        # Уведомление клиенту
        try:
            await bot.send_message(
                order['user_id'],
                f"✅ <b>Заказ #{order_id} подтвержден!</b>\n\n"
                "Ваш заказ принят в работу. Скоро с вами свяжется менеджер для уточнения деталей.",
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления клиенту: {e}")
        
        # Обновление сообщения менеджера
        await callback.message.edit_text(
            callback.message.text + "\n\n✅ <b>ПОДТВЕРЖДЕН</b>",
            parse_mode="HTML"
        )
        logger.info(f"Заказ #{order_id} подтвержден менеджером")
    else:
        await callback.answer("Заказ не найден", show_alert=True)
    
    await callback.answer("Заказ подтвержден")

# Обработка отмены заказа менеджером
@dp.callback_query(F.data.startswith("manager_cancel:"))
async def handle_manager_cancel(callback: types.CallbackQuery):
    """Отмена заказа менеджером"""
    order_id = callback.data.split(":")[1]
    
    if order_id in orders:
        order = orders[order_id]
        order['status'] = 'cancelled_by_manager'
        
        # Уведомление клиенту
        try:
            await bot.send_message(
                order['user_id'],
                f"❌ <b>Заказ #{order_id} отменен</b>\n\n"
                "К сожалению, ваш заказ не может быть выполнен. "
                "Для уточнения деталей свяжитесь с менеджером.",
                parse_mode="HTML",
                reply_markup=InlineKeyboardBuilder().button(
                    text="💬 Связаться с менеджером",
                    url=MANAGER_URL
                ).as_markup()
            )
        except Exception as e:
            logger.error(f"Ошибка отправки уведомления клиенту: {e}")
        
        # Обновление сообщения менеджера
        await callback.message.edit_text(
            callback.message.text + "\n\n❌ <b>ОТМЕНЕН</b>",
            parse_mode="HTML"
        )
        logger.info(f"Заказ #{order_id} отменен менеджером")
    else:
        await callback.answer("Заказ не найден", show_alert=True)
    
    await callback.answer("Заказ отменен")

async def main():
    """Запуск бота"""
    try:
        logger.info("🚀 Бот запускается...")
        await dp.start_polling(bot, skip_updates=True)
    except Exception as e:
        logger.error(f"❌ Ошибка при запуске бота: {e}")
    finally:
        await bot.session.close()
        logger.info("👋 Бот остановлен")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("⚠️ Бот остановлен пользователем")
