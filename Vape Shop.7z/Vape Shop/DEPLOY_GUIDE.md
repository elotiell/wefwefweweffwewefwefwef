# 🚀 Гайд по развертыванию NextGenVape на Ubuntu 22.04

## 📋 Содержание
1. [Подготовка сервера](#1-подготовка-сервера)
2. [Установка необходимого ПО](#2-установка-необходимого-по)
3. [Перенос файлов](#3-перенос-файлов)
4. [Настройка Nginx](#4-настройка-nginx)
5. [Настройка бота](#5-настройка-бота)
6. [Запуск через Screen](#6-запуск-через-screen)
7. [Автозапуск](#7-автозапуск)
8. [Полезные команды](#8-полезные-команды)

---

## 1. Подготовка сервера

### Подключение к серверу
```bash
ssh root@your_server_ip
# или
ssh username@your_server_ip
```

### Обновление системы
```bash
sudo apt update
sudo apt upgrade -y
```

### Создание пользователя (если нужно)
```bash
sudo adduser vapebot
sudo usermod -aG sudo vapebot
su - vapebot
```

---

## 2. Установка необходимого ПО

### Установка Python и pip
```bash
sudo apt install python3 python3-pip python3-venv -y
```

### Установка Nginx (веб-сервер для раздачи HTML)
```bash
sudo apt install nginx -y
```

### Установка Screen
```bash
sudo apt install screen -y
```

### Установка Git (опционально, для будущих обновлений)
```bash
sudo apt install git -y
```

---

## 3. Перенос файлов

### Вариант 1: Через SCP (с вашего компьютера)

На вашем **Windows** компьютере откройте PowerShell в папке проекта:

```powershell
# Перейти в папку проекта
cd "C:\Users\kenzo\Desktop\Vape Shop"

# Создать архив (если есть 7zip или используйте WinRAR)
# Или просто скопировать файлы напрямую:

# Скопировать всю папку на сервер
scp -r . username@your_server_ip:/home/username/vape-shop/
```

### Вариант 2: Через WinSCP (графический интерфейс)

1. Скачайте WinSCP: https://winscp.net/
2. Подключитесь к серверу
3. Перетащите папку `Vape Shop` на сервер

### На сервере создайте структуру папок:

```bash
# Создать директории
mkdir -p ~/vape-shop
cd ~/vape-shop

# Если файлы уже скопированы через SCP, пропустите этот шаг
```

---

## 4. Настройка Nginx

### Создать конфигурацию для веб-приложения

```bash
sudo nano /etc/nginx/sites-available/vapebot
```

Вставьте следующую конфигурацию:

```nginx
server {
    listen 80;
    server_name your_domain.com;  # или IP адрес сервера
    
    root /home/username/vape-shop/miniapp;
    index index.html;
    
    # Логи
    access_log /var/log/nginx/vapebot_access.log;
    error_log /var/log/nginx/vapebot_error.log;
    
    location / {
        try_files $uri $uri/ =404;
    }
    
    # Кэширование статических файлов
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    # Безопасность
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

**Замените:**
- `your_domain.com` на ваш домен или IP
- `/home/username/` на путь к вашему пользователю

### Активировать конфигурацию

```bash
# Создать символическую ссылку
sudo ln -s /etc/nginx/sites-available/vapebot /etc/nginx/sites-enabled/

# Удалить дефолтную конфигурацию (опционально)
sudo rm /etc/nginx/sites-enabled/default

# Проверить конфигурацию
sudo nginx -t

# Перезапустить Nginx
sudo systemctl restart nginx

# Включить автозапуск
sudo systemctl enable nginx
```

### Проверка
Откройте в браузере: `http://your_server_ip` - должен открыться ваш сайт

---

## 5. Настройка бота

### Создать виртуальное окружение

```bash
cd ~/vape-shop

# Создать venv
python3 -m venv venv

# Активировать
source venv/bin/activate
```

### Установить зависимости

```bash
pip install -r requirements.txt
```

Если файл `requirements.txt` не существует, установите вручную:

```bash
pip install python-telegram-bot
```

### Настроить bot.py

```bash
nano bot.py
```

Убедитесь, что в коде указаны правильные данные:
- `BOT_TOKEN` - токен вашего бота
- `WEB_APP_URL` - URL вашего веб-приложения (например, `http://your_server_ip`)

**Важно:** Замените URL в bot.py на адрес вашего сервера:

```python
WEB_APP_URL = "http://your_server_ip"  # или https://your_domain.com
```

### Создать файл с переменными окружения (безопасность)

```bash
nano .env
```

Добавьте:
```
BOT_TOKEN=ваш_токен_бота
ADMIN_CHAT_ID=ваш_телеграм_id
WEB_APP_URL=http://your_server_ip
```

Обновите bot.py для использования .env (если нужно):
```python
from dotenv import load_dotenv
import os

load_dotenv()
BOT_TOKEN = os.getenv('BOT_TOKEN')
```

---

## 6. Запуск через Screen

### Что такое Screen?
Screen позволяет запускать процессы в фоновом режиме, которые не прерываются при отключении от SSH.

### Создать screen сессию

```bash
# Создать новую сессию с именем "vapebot"
screen -S vapebot
```

### Запустить бота

```bash
cd ~/vape-shop
source venv/bin/activate
python3 bot.py
```

Бот запустится и вы увидите логи.

### Отключиться от screen (бот продолжит работу)

Нажмите: `Ctrl + A`, затем `D` (detach)

### Основные команды Screen

```bash
# Список всех сессий
screen -ls

# Подключиться к сессии
screen -r vapebot

# Создать новую сессию
screen -S имя_сессии

# Убить сессию (если нужно остановить бота)
screen -S vapebot -X quit

# Отключиться от сессии
# Нажать: Ctrl+A, затем D
```

### Проверка работы

```bash
# Посмотреть все сессии
screen -ls

# Вывод должен быть:
# There is a screen on:
#     12345.vapebot   (Detached)
```

---

## 7. Автозапуск

Чтобы бот автоматически запускался при перезагрузке сервера:

### Вариант 1: Systemd Service (рекомендуется)

Создайте service файл:

```bash
sudo nano /etc/systemd/system/vapebot.service
```

Вставьте:

```ini
[Unit]
Description=NextGenVape Telegram Bot
After=network.target

[Service]
Type=simple
User=username
WorkingDirectory=/home/username/vape-shop
Environment="PATH=/home/username/vape-shop/venv/bin"
ExecStart=/home/username/vape-shop/venv/bin/python3 /home/username/vape-shop/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**Замените `username` на ваше имя пользователя!**

Активируйте сервис:

```bash
# Перезагрузить systemd
sudo systemctl daemon-reload

# Запустить бота
sudo systemctl start vapebot

# Включить автозапуск
sudo systemctl enable vapebot

# Проверить статус
sudo systemctl status vapebot

# Остановить бота
sudo systemctl stop vapebot

# Перезапустить
sudo systemctl restart vapebot

# Посмотреть логи
sudo journalctl -u vapebot -f
```

### Вариант 2: Crontab (если предпочитаете screen)

```bash
crontab -e
```

Добавьте строку:

```bash
@reboot cd /home/username/vape-shop && /usr/bin/screen -dmS vapebot /home/username/vape-shop/venv/bin/python3 /home/username/vape-shop/bot.py
```

---

## 8. Полезные команды

### Мониторинг

```bash
# Посмотреть процессы Python
ps aux | grep python

# Посмотреть использование ресурсов
htop

# Логи Nginx
sudo tail -f /var/log/nginx/vapebot_access.log
sudo tail -f /var/log/nginx/vapebot_error.log

# Логи бота (если используете systemd)
sudo journalctl -u vapebot -f

# Проверить порты
sudo netstat -tulpn | grep :80
```

### Обновление кода

```bash
# Остановить бота
screen -S vapebot -X quit
# или
sudo systemctl stop vapebot

# Обновить файлы (через SCP или git pull)
cd ~/vape-shop

# Запустить снова
screen -S vapebot
source venv/bin/activate
python3 bot.py
# или
sudo systemctl start vapebot
```

### Настройка Firewall (UFW)

```bash
# Установить UFW
sudo apt install ufw -y

# Разрешить SSH
sudo ufw allow 22/tcp

# Разрешить HTTP
sudo ufw allow 80/tcp

# Разрешить HTTPS (если будете настраивать SSL)
sudo ufw allow 443/tcp

# Включить firewall
sudo ufw enable

# Проверить статус
sudo ufw status
```

---

## 🔒 SSL/HTTPS (опционально, но рекомендуется)

Для защищенного соединения установите Let's Encrypt:

```bash
# Установить Certbot
sudo apt install certbot python3-certbot-nginx -y

# Получить SSL сертификат
sudo certbot --nginx -d your_domain.com

# Автообновление сертификата
sudo certbot renew --dry-run
```

После этого Telegram WebApp будет работать по HTTPS.

---

## 📝 Checklist развертывания

- [ ] Сервер обновлен (apt update && apt upgrade)
- [ ] Установлен Python 3, pip, venv
- [ ] Установлен Nginx
- [ ] Установлен Screen
- [ ] Файлы проекта скопированы на сервер
- [ ] Nginx настроен и запущен
- [ ] Виртуальное окружение создано
- [ ] Зависимости установлены (requirements.txt)
- [ ] bot.py настроен (токен, URL)
- [ ] Бот запущен через screen или systemd
- [ ] Автозапуск настроен
- [ ] Firewall настроен
- [ ] SSL сертификат установлен (опционально)
- [ ] Бот работает и отвечает в Telegram

---

## 🆘 Troubleshooting

### Nginx не запускается
```bash
sudo nginx -t  # Проверить конфигурацию
sudo systemctl status nginx  # Посмотреть ошибки
```

### Бот не отвечает
```bash
# Проверить логи
sudo journalctl -u vapebot -n 50

# Проверить запущен ли процесс
ps aux | grep bot.py

# Перезапустить
sudo systemctl restart vapebot
```

### Не открывается сайт
```bash
# Проверить работает ли Nginx
sudo systemctl status nginx

# Проверить файрвол
sudo ufw status

# Проверить права на файлы
ls -la ~/vape-shop/miniapp/
```

### Screen сессия пропала
```bash
# Посмотреть все сессии
screen -ls

# Создать заново
screen -S vapebot
cd ~/vape-shop
source venv/bin/activate
python3 bot.py
```

---

## 📞 Контакты и поддержка

После развертывания протестируйте:
1. Откройте бота в Telegram
2. Нажмите кнопку "🛍️ Открыть магазин"
3. Проверьте, что загружается веб-приложение
4. Оформите тестовый заказ
5. Проверьте, что бот получает заказ

**Готово! Ваш магазин работает 24/7! 🎉**

---

## 📄 Быстрая шпаргалка команд

```bash
# === SCREEN ===
screen -S vapebot              # Создать сессию
screen -ls                     # Список сессий
screen -r vapebot              # Подключиться
Ctrl+A, затем D               # Отключиться
screen -S vapebot -X quit     # Убить сессию

# === SYSTEMD ===
sudo systemctl start vapebot   # Запустить
sudo systemctl stop vapebot    # Остановить
sudo systemctl restart vapebot # Перезапустить
sudo systemctl status vapebot  # Статус
sudo journalctl -u vapebot -f  # Логи

# === NGINX ===
sudo systemctl restart nginx   # Перезапустить
sudo nginx -t                  # Проверить конфиг
sudo tail -f /var/log/nginx/vapebot_access.log

# === ОБНОВЛЕНИЕ ===
# 1. Остановить бота
sudo systemctl stop vapebot
# 2. Обновить файлы (scp новые файлы)
# 3. Запустить бота
sudo systemctl start vapebot
```

---

**Удачи в развертывании! 🚀**

